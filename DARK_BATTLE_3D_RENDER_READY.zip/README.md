# DARK BATTLE 3D — Render-ready multiplayer lobby

## Deploy on Render
1. Upload the contents of this folder to the ROOT of your GitHub repository (not just the ZIP file).
2. In Render create **New → Web Service** and connect that repository.
3. Runtime: Node. Build command: `npm install`. Start command: `npm start`.
4. If Render has an old Python service configured, create a new Web Service for this Node.js project.
5. After deployment, open the Render URL. `/health` should return JSON with `ok: true`.
6. Create a room and share its 5-character code with friends who open the same URL.

This project uses Express and WebSocket (`ws`). Render supplies the port through `process.env.PORT`.

## Current scope
Private room creation/joining, room roster, host indicator, 8-player room cap, and host start action. This is a lobby/server starter; real 3D movement synchronization and authoritative combat are not implemented in this package yet.
