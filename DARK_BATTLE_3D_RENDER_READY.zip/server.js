const express = require("express");
const http = require("http");
const { WebSocketServer, WebSocket } = require("ws");
const crypto = require("crypto");
const path = require("path");

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server });
const rooms = new Map();
app.use(express.static(path.join(__dirname, "public")));
app.get("/health", (_req, res) => res.json({ ok: true, game: "DARK BATTLE 3D" }));

function code() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let result;
  do {
    result = Array.from({length:5}, () => chars[crypto.randomInt(chars.length)]).join("");
  } while (rooms.has(result));
  return result;
}
function send(ws, data) {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(data));
}
function snapshot(roomCode) {
  const room = rooms.get(roomCode);
  if (!room) return;
  const players = [...room.players.values()].map(p => ({
    id: p.id, name: p.name, host: p.id === room.hostId
  }));
  for (const p of room.players.values()) send(p.ws, {
    type: "room-update", code: roomCode, players, hostId: room.hostId,
    started: room.started, maxPlayers: 8
  });
}
function leave(ws) {
  const roomCode = ws.roomCode;
  if (!roomCode || !rooms.has(roomCode)) return;
  const room = rooms.get(roomCode);
  room.players.delete(ws.playerId);
  if (room.hostId === ws.playerId) {
    const next = room.players.keys().next();
    room.hostId = next.done ? null : next.value;
  }
  if (room.players.size === 0) rooms.delete(roomCode);
  else snapshot(roomCode);
  ws.roomCode = null;
  ws.playerId = null;
}
wss.on("connection", ws => {
  ws.playerId = crypto.randomUUID();
  ws.roomCode = null;
  send(ws, {type:"connected", id:ws.playerId});
  ws.on("message", raw => {
    let msg;
    try { msg = JSON.parse(raw.toString()); } catch { return send(ws,{type:"error",message:"رسالة غير صالحة"}); }
    if (msg.type === "create-room") {
      leave(ws);
      const roomCode = code();
      const player = {id:ws.playerId, name:String(msg.name||"Player").slice(0,18), ws};
      rooms.set(roomCode,{hostId:ws.playerId,players:new Map([[ws.playerId,player]]),started:false});
      ws.roomCode = roomCode;
      send(ws,{type:"room-created",code:roomCode});
      snapshot(roomCode);
    } else if (msg.type === "join-room") {
      leave(ws);
      const roomCode = String(msg.code||"").toUpperCase().replace(/[^A-Z0-9]/g,"");
      const room = rooms.get(roomCode);
      if (!room) return send(ws,{type:"error",message:"رمز الغرفة غير موجود. تحقق من الرمز."});
      if (room.started) return send(ws,{type:"error",message:"المباراة بدأت بالفعل."});
      if (room.players.size >= 8) return send(ws,{type:"error",message:"الغرفة ممتلئة (8 لاعبين)."});
      const player = {id:ws.playerId,name:String(msg.name||"Player").slice(0,18),ws};
      room.players.set(ws.playerId,player);
      ws.roomCode = roomCode;
      send(ws,{type:"joined-room",code:roomCode});
      snapshot(roomCode);
    } else if (msg.type === "start-match") {
      const room = rooms.get(ws.roomCode);
      if (!room || room.hostId !== ws.playerId) return send(ws,{type:"error",message:"منشئ الغرفة فقط يمكنه بدء المباراة."});
      if (room.players.size < 2) return send(ws,{type:"error",message:"تحتاج إلى لاعب آخر على الأقل لبدء المباراة."});
      room.started = true;
      snapshot(ws.roomCode);
      for (const p of room.players.values()) send(p.ws,{type:"match-started",message:"بدأت المباراة! (نظام اللعب الفعلي يضاف في مرحلة لاحقة)"});
    } else if (msg.type === "leave-room") {
      leave(ws);
      send(ws,{type:"left-room"});
    }
  });
  ws.on("close", () => leave(ws));
});
const port = process.env.PORT || 3000;
server.listen(port, "0.0.0.0", () => console.log(`DARK BATTLE 3D listening on ${port}`));
