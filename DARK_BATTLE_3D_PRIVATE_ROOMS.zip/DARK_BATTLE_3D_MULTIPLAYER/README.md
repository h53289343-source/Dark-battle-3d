# DARK BATTLE 3D — Private Rooms (v0.3)

## Features
- Create a private room with a random 5-character code.
- Friends join the same room by entering that code.
- Rooms are isolated; players in different rooms do not see each other.
- Up to 8 players per room.
- Live position and facing-direction synchronization.
- Browser client with mobile touch controls.

## Run locally
Requires Node.js 18 or newer. In this folder run:

```bash
npm install
npm start
```

Then open http://localhost:3000. For testing on multiple devices, deploy the whole folder as a Node.js web service with WebSocket support (for example Render or Railway), using `npm install` as build command and `npm start` as start command. Do not use static-only hosting for this version because the Socket.IO server must run.

## Play with friends
1. Open the deployed game URL.
2. Enter a player name and press **Create new room**.
3. Share the displayed five-character code with friends.
4. Friends open the same URL, enter the code and press **Join**.
5. Press **Enter match** after joining.

Three.js is loaded from a CDN, so the browser needs internet access. This is an early prototype: room codes and player movement work, but combat damage, voice chat, persistence and anti-cheat are not implemented.
