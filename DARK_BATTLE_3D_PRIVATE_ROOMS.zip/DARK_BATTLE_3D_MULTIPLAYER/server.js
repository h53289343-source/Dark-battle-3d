const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');
const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });
const rooms = new Map();
app.use(express.static(__dirname));
app.get('/health', (_req,res)=>res.json({ok:true,rooms:rooms.size}));
const cleanName = value => String(value || 'PLAYER').replace(/[^\p{L}\p{N}_ -]/gu,'').trim().slice(0,14) || 'PLAYER';
function makeCode(){let code;do{code=Math.random().toString(36).slice(2,7).toUpperCase()}while(code.length!==5||rooms.has(code));return code}
function playerData(s){return {id:s.id,name:s.data.playerName||'PLAYER',x:s.data.x||0,y:s.data.y||.85,z:s.data.z||0,yaw:s.data.yaw||0,color:s.data.color||0x39cfff}}
function roomPlayers(code){const r=rooms.get(code);return r?[...r].map(id=>io.sockets.sockets.get(id)).filter(Boolean).map(playerData):[]}
function emitRoom(code){const list=roomPlayers(code);io.to(code).emit('players',list)}
function leaveRoom(socket){const code=socket.data.room;if(!code)return;socket.leave(code);const r=rooms.get(code);if(r){r.delete(socket.id);if(r.size===0)rooms.delete(code);else emitRoom(code)}socket.data.room=null}
function enterRoom(socket,code,name){const room=rooms.get(code);if(!room){socket.emit('roomError','لم يتم العثور على هذه الغرفة. تحقق من الرمز.');return}if(room.size>=8&&!room.has(socket.id)){socket.emit('roomError','الغرفة ممتلئة (الحد الأقصى 8 لاعبين).');return}leaveRoom(socket);socket.data.room=code;socket.data.playerName=cleanName(name);socket.data.x=(Math.random()-.5)*8;socket.data.y=.85;socket.data.z=(Math.random()-.5)*8;socket.data.yaw=0;socket.join(code);socket.emit('roomJoined',{code,players:roomPlayers(code)});emitRoom(code);io.to(code).emit('playerJoined',playerData(socket))}
io.on('connection',socket=>{
 socket.on('createRoom',data=>{leaveRoom(socket);const code=makeCode();rooms.set(code,new Set([socket.id]));socket.data.room=code;socket.data.playerName=cleanName(data?.name);socket.data.x=0;socket.data.y=.85;socket.data.z=9;socket.data.yaw=0;socket.join(code);socket.emit('roomCreated',{code,players:roomPlayers(code)});emitRoom(code)});
 socket.on('joinRoom',data=>{const code=String(data?.code||'').toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,5);if(!/^[A-Z0-9]{5}$/.test(code)){socket.emit('roomError','رمز الغرفة يجب أن يتكوّن من 5 أحرف أو أرقام.');return}enterRoom(socket,code,data?.name)});
 socket.on('move',data=>{const code=socket.data.room;if(!code||!rooms.has(code))return;for(const k of ['x','y','z','yaw']){const v=Number(data?.[k]);if(Number.isFinite(v))socket.data[k]=Math.max(-120,Math.min(120,v))}socket.to(code).emit('playerMoved',playerData(socket))});
 socket.on('disconnect',()=>leaveRoom(socket));
});
const port=process.env.PORT||3000;server.listen(port,'0.0.0.0',()=>console.log(`DARK BATTLE 3D server listening on ${port}`));
